package assistedpractices;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice10 {
	 public static void main(String[] args) {
	        // Example 1: Verifying an email address
	        String email = "user@example.com";
	        String emailPattern = "^[a-zA-Z0-9_]+@[a-zA-Z0-9]+\\.[a-zA-Z]{2,}$";

	        if (verifyPattern(email, emailPattern)) {
	            System.out.println(email + " is a valid email address.");
	        } else {
	            System.out.println(email + " is not a valid email address.");
	        }

	        // Example 2: Verifying a phone number
	        String phoneNumber = "123-456-7890";
	        String phonePattern = "^\\d{3}-\\d{3}-\\d{4}$";

	        if (verifyPattern(phoneNumber, phonePattern)) {
	            System.out.println(phoneNumber + " is a valid phone number.");
	        } else {
	            System.out.println(phoneNumber + " is not a valid phone number.");
	        }
	    }

	    private static boolean verifyPattern(String input, String pattern) {
	        Pattern regexPattern = Pattern.compile(pattern);
	        Matcher matcher = regexPattern.matcher(input);
	        return matcher.matches();
	    }
}
