package assistedpractices;

 class Practice4 {
	int id;
	String name;
	Practice4(int i,String n)
	{
	id=i;
	name=n;
	}


	void display() {
	System.out.println(id+" hello "+name);
	}

public static void main(String[] args) {

	Practice4 emp1=new Practice4(1,"sam");
	Practice4 emp2=new Practice4(2,"honey");

	emp1.display();
	emp2.display();
	}
}
 
