package assistedpractices;

import java.util.LinkedList;
import java.util.Queue;

public class Project28 {
	public static void main(String[] args) {
		   
        Queue<String> cityQueue = new LinkedList<>();
      
        cityQueue.offer("pune");
        cityQueue.offer("Mumbai");
        cityQueue.offer("Hyd");
        
        System.out.println("City Queue: " + cityQueue);
       
        String removedCity = cityQueue.poll();
        System.out.println("Dequeued city: " + removedCity);
        
        System.out.println("City Queue after dequeue: " + cityQueue);
       
        cityQueue.offer("Italy");
        System.out.println("City Queue after enqueue: " + cityQueue);
        
       
        String frontCity = cityQueue.peek();
        System.out.println("Front city: " + frontCity);
//TODO Auto-generated method stub

}

}
