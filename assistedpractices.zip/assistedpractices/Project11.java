package assistedpractices;

class Mythread extends Thread {
	@Override
	public void run() {
	   System.out.println("Thread created by extending Thread class.");
	  // for (int i = 0; i < 6; i++) {
	      // System.out.println("Thread: " + i);
	      
	   }
}
class MyRunnable implements Runnable {
		public void run() {
		   System.out.println("Thread created by implementing Runnable interface.");
		   for (int i = 0; i < 3; i++) {
		       System.out.println("Thread: " + i); 
		   }
		}
}
		
 public class Project11 {
	public static void main( String args[] )
 	{
		Mythread  mt = new Mythread ();
  		mt.start();
  	     MyRunnable runnable = new MyRunnable();
	     Thread thread2 = new Thread(runnable);
	     thread2.start();

 	}

	}


