package assistedpractices;

public class Project33 {
	public static void main(String[] args) {
		// Create an array of integers
        int[] arr = {45,78,24,63,8,78,22,7};

        // Bubble sort the array
        bubbleSort(arr);

        // Print the sorted array
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    private static void bubbleSort(int[] arr) {

        // Loop through the array from beginning to end
        for (int i = 0; i < arr.length - 1; i++) {

            // Compare each pair of adjacent elements
            for (int j = 0; j < arr.length - i - 1; j++) {

                // If the current element is greater than the next element, swap them
                if (arr[j] > arr[j + 1]) {

                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
// TODO Auto-generated method stub

	}

}
