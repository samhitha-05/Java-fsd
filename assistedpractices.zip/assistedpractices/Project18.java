package assistedpractices;
class Myclasses1 {
	int a,b;
	void get(int x,int y) {
		a=x;
		b=y;
	}
	void disp() {
		System.out.println("classes and objects");
		System.out.println(a);
		System.out.println(b);
		}
}

public class Project18 {
	public static void main(String[] args) {
		Myclasses1 m=new Myclasses1(),m1=new Myclasses1();
		m.get(10,200);
		m1.get(300,40);
		m.disp();
		m1.disp();
	}
}
