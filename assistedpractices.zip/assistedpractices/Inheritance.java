package assistedpractices;
class Vehicle {
	 private String brand;
	 private String model;
	 private int year;

	 // Constructor
	 public Vehicle(String brand, String model, int year) {
	     this.brand = brand;
	     this.model = model;
	     this.year = year;
	 }

	 
	 public String getBrand() {
	     return brand;
	 }

	 public void setBrand(String brand) {
	     this.brand = brand;
	 }

	 
	 public String getModel() {
	     return model;
	 }

	 public void setModel(String model) {
	     this.model = model;
	 }

	 
	 public int getYear() {
	     return year;
	 }

	 public void setYear(int year) {
	     this.year = year;
	 }

	 // Method to display vehicle information
	 public void display() {
	     System.out.println("Brand: " + brand);
	     System.out.println("Model: " + model);
	     System.out.println("Year: " + year);
	 }
	}

	// inheriting from Vehicle
	class Car extends Vehicle {
	 private int numDoors;

	 // Constructor
	 public Car(String brand, String model, int year, int numDoors) {
	     super(brand, model, year);
	     this.numDoors = numDoors;
	 }

	 // Getter and Setter methods for numDoors
	 public int getNumDoors() {
	     return numDoors;
	 }

	 public void setNumDoors(int numDoors) {
	     this.numDoors = numDoors;
	 }

	 
	 public void display() {
	     super.display();
	     System.out.println("Number of doors: " + numDoors);
	 }
	}

public class Inheritance {
	public static void main(String[] args) {
		// Creating an object of the Car class
	     Car car = new Car("Maruti Suzuki", "Dzire", 2023, 3);

	     System.out.println("Car brand: " + car.getBrand());
	     car.setModel("Swift");
	     System.out.println("Updated car model: " + car.getModel());

	     System.out.println("Car year: " + car.getYear());
	     car.setYear(2020);
	     System.out.println("Updated car year: " + car.getYear());

	     System.out.println("Number of doors: " + car.getNumDoors());
	     car.setNumDoors(2);
	     System.out.println("Updated number of doors: " + car.getNumDoors());

	     // Displaying information about the car
	     car.display();
// TODO Auto-generated method stub

	}

}
