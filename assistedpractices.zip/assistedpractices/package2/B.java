package package2;

import package1.*;

public class B {
public static void main(String[] args) {
		
		C obj = new C(); 
        obj.display2();  
		
	}

	}
	

