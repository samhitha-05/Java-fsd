package package2;

import package1.*;

public class D extends A {
	public static void main(String[] args) {
	D obj = new D ();   
    obj.display1();  

	
}
}

