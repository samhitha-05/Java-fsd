package assistedpractices;
class SharedResource {
    private int value = 0;

    public synchronized void increment() {
        value++;
        System.out.println("Value incremented: " + value);
    }

    public synchronized void decrement() {
        value--;
        System.out.println("Value decremented: " + value);
    }
}

class MyThread1 extends Thread {
    private SharedResource resource;

    public MyThread1(SharedResource resource) {
        this.resource = resource;
    }

    public void run() {
        for (int i = 0; i < 3; i++) {
            resource.increment();
            resource.decrement();
        }
    }
}

public class Project13 {
	public static void main(String[] args) {
		SharedResource resource = new SharedResource();

        MyThread1 thread1 = new MyThread1(resource);
        MyThread1 thread2 = new MyThread1(resource);

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
// TODO Auto-generated method stub

	}

}
