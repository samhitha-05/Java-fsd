package assistedpractices;

public class Project34 {
	public static void main(String[] args) {
		int[] array = {1, 2, 3, 4, 5};
        int elementToInsert = 10;
        int positionToInsert = 2;

        // Create a new array with increased size
        int[] newArray = new int[array.length + 1];
        for (int i = 0; i < positionToInsert; i++) {
            newArray[i] = array[i];
        }

        newArray[positionToInsert] = elementToInsert;
        for (int i = positionToInsert; i < array.length; i++) {
            newArray[i + 1] = array[i];
        }

        // Print the new array
        for (int i = 0; i < newArray.length; i++) {
            System.out.print(newArray[i] + " ");
        }
// TODO Auto-generated method stub

	}


}
