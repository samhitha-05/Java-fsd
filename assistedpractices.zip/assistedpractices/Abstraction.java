package assistedpractices;
abstract class Animal {
	   abstract void makeSound();
	}

	class Dog extends Animal {
	   void makeSound() {
	      System.out.println("Woof");
	   }
	}

	class Cat extends Animal {
	   void makeSound() {
	      System.out.println("Meow");
	   }
	}

public class Abstraction {
	public static void main(String[] args) {
		Animal myDog = new Dog();
	      Animal myCat = new Cat();
	      myDog.makeSound();
	      myCat.makeSound();
// TODO Auto-generated method stub

	}

}
