package assistedpractices;

public class Project12 {
	public static void main(String[] args) {
		Thread thread1 = new Thread(() -> {
            synchronized (Project12.class) {
                System.out.println("Thread 1 started");
                try {
                    Thread.sleep(2000); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Thread 1 completed");
                Project12.class.notify(); // Notify waiting threads
            }
        });

        Thread thread2 = new Thread(() -> {
            synchronized (Project12.class) {
                System.out.println("Thread 2 started");
                try {
                	Project12.class.wait(); // Wait until notified
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Thread 2 waiting");
                System.out.println("Thread 2 completed");
            }
        });

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All threads completed");

// TODO Auto-generated method stub

	}

}
