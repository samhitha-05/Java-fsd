package assistedpractices;

public class Practice9 {
	 public static void main(String[] args) {
	        // Single-dimensional array
	        int[] numbers = {1, 2, 3, 4, 5};

	        // Displaying elements of the single-dimensional array
	        System.out.print("Single-dimensional array elements: ");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.print(numbers[i] + " ");
	        }

	        // Multidimensional array (2D array)
	        int[][] matrix = {
	                {1, 2, 3},
	                {4, 5, 6},
	                {7, 8, 9}
	        };

	        // Displaying elements of the 2D array
	        System.out.println("\n\nMultidimensional array (2D array) elements:");
	        for (int row = 0; row < matrix.length; row++) {
	            for (int col = 0; col < matrix[row].length; col++) {
	                System.out.print(matrix[row][col] + " ");
	            }
	            System.out.println();
	        }
	    }
}
