package assistedpractices;

public class Practice3 {
	public int multipynumbers(int a,int b) {
		int z=a*b;
		return z;
	}
	

		int val=40;

		int operation(int val) {
			val =val*10/100;
			return(val);
		}
		public void area(int b,int h)
	    {
	         System.out.println("Area of Triangle : "+(0.5*b*h));
	    }
	    public void area(int r) 
	    {
	         System.out.println("Area of Circle : "+(3.14*r*r));
	    }



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Practice3 b=new Practice3();
		int ans= b.multipynumbers(7,98);
		System.out.println("Multipilcation is :"+ans);
		 Practice3 d =  new  Practice3();
		System.out.println("Before operation value of data is "+d.val);
		d.operation(40);
		System.out.println("After operation value of data is "+d.val);
		d.area(67,28);
		d.area(54);
	}
	}
	


