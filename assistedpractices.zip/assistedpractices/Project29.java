package assistedpractices;

import java.util.Scanner;

public class Project29 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        // Input the array size
        System.out.print("Enter the number of elements in the array: ");
        int size = scanner.nextInt();
        
        // Create the array
        int[] arr = new int[size];

        // Input the array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        // Input the target element
        System.out.print("Enter the target element to search: ");
        int target = scanner.nextInt();

        // Perform linear search
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (arr[i] == target) {
                index = i;
                break;
            }
        }

        // Output the result
        if (index != -1) {
            System.out.println("Element " + target + " found at index " + index);
        } else {
            System.out.println("Element not found in the array");
        }

        scanner.close();
// TODO Auto-generated method stub

	}

}
