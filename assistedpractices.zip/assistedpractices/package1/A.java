package package1;



public class A {
	protected void display1() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

	

}