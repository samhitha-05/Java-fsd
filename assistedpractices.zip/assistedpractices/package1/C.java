package package1;

public class C {
	public void display2() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 

	

}
