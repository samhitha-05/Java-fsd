package assistedpractices;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Practice6 {
	 public static void main(String[] args) {
	        // HashMap verification
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("Key 1", 10);
	        hashMap.put("Key 2", 20);

	        verifyMap(hashMap, "HashMap");

	        // TreeMap verification
	        Map<String, Integer> treeMap = new TreeMap<>();
	        treeMap.put("Key 1", 10);
	        treeMap.put("Key 3", 30);
	        treeMap.put("Key 2", 20);

	        verifyMap(treeMap, "TreeMap");
	    }

	    private static void verifyMap(Map<String, Integer> map, String mapType) {
	        // Verifying if the map contains a specific key
	        String keyToCheck = "Key 1";
	        if (map.containsKey(keyToCheck)) {
	            System.out.println(mapType + " verification successful! Value for " + keyToCheck + ": " + map.get(keyToCheck));
	        } else {
	            System.out.println(mapType + " verification failed!");
	        }

	        // Displaying the contents of the map
	        System.out.println(mapType + " Contents: " + map);
	    }
}
