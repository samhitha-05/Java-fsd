package assistedpractices;
class Nodee {
    int data;
    Nodee prev;
    Nodee next;

    public Nodee(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class Project26 {
	private Nodee head;
    private Nodee tail;

    public Project26() {
        this.head = null;
        this.tail = null;
    }

    public void insert(int data) {
        Nodee newNode = new Nodee(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void traverseForward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Nodee curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        if (tail == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Nodee curr = tail;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.prev;
        }
        System.out.println();
    }

	public static void main(String[] args) {
		Project26 list = new Project26();
        list.insert(21);
        list.insert(2);
        list.insert(25);
        list.insert(8);
        list.insert(31);

        System.out.println("Traversing the Doubly Linked List in forward direction:");
        list.traverseForward();

        System.out.println("Traversing the Doubly Linked List in backward direction:");
        list.traverseBackward();
// TODO Auto-generated method stub

	}

}
