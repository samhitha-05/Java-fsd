package assistedpractices;

public class Practice7 {

}
