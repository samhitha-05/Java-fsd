package assistedpractices;
class Sum {
	 public int calculateSum(int a, int b) {
	     return a + b;
	 }
	}

	// inheriting from Sum
	class SumExtended extends Sum {
	 @Override
	 public int calculateSum(int a, int b) {
	     return super.calculateSum(a, b) * 2;
	 }
	}

public class Polymorphism {

	public static void main(String[] args) {
        Sum sum1 = new Sum();
   Sum sum2 = new SumExtended();

   int result1 = sum1.calculateSum(20, 3);
   System.out.println("Result from Sum class: " + result1); 

   int result2 = sum2.calculateSum(2, 3);
   System.out.println("Result from SumExtended class: " + result2); 
// TODO Auto-generated method stub

	}


}
