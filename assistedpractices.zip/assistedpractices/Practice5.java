package assistedpractices;

import java.util.List;
import java.util.ArrayList;
public class Practice5 {
	public static void main(String[] args) {
        // Creating a sample list
        List<String> sampleList = new ArrayList<>();
        sampleList.add("Item 1");
        sampleList.add("Item 2");

        // Verifying if the list contains a specific item
        if (sampleList.contains("Item 1")) {
            System.out.println("Collection verification successful!");
        } else {
            System.out.println("Collection verification failed!");
        }

        // Displaying the contents of the list
        System.out.println("List Contents: " + sampleList);
    }
}
