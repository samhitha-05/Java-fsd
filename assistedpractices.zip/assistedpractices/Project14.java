package assistedpractices;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Project14 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        int numerator, denominator, result;

        System.out.println("Enter the numerator:");
        numerator = scanner.nextInt();

        System.out.println("Enter the denominator:");
        try {
            denominator = scanner.nextInt();
            result = numerator / denominator;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter an integer.");
        }
// TODO Auto-generated method stub

	}

}
