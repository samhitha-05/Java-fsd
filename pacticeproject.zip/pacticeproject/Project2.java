package pacticeproject;


	import java.util.Arrays;
	import java.util.Scanner;
	public class Project2 {
	 public static void main(String[] args) {
	 String[] EmailIDs = {
	 "amazon.abc@shopping.com",
	 "trends.ajio@clothing.com",
	 "godaddy.email@website.com", // Array of email IDs
	 "yahoo.mail@website.com",
	 "linkedin.job@searchjob.com"
	 };
	 // Prompt the user to enter an email ID to search
	 Scanner sc = new Scanner(System.in);
	 System.out.print("Enter the email ID to search: ");
	 String searchEmail = sc.nextLine();
	 // Validate the entered email ID format
	 if (!isValidEmail(searchEmail)) {
	 System.out.println("Invalid email ID format.");
	 return;
	 }
	 // Search the email ID in the array
	 boolean found = false;
	 for (String email : EmailIDs) {
	 if (email.equalsIgnoreCase(searchEmail)) {
	 found = true;
	 break;
	 }
	 }
	 // Display the result
	 if (found) {
	 System.out.println("Email ID found!");
	 } else {
	 System.out.println("Email ID not found.");
	 }
	 }
	 // Method to validate the email ID format
	 public static boolean isValidEmail(String email) {
	 // Regular expression for email validation
	 String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	 return email.matches(emailRegex);
	 }
	}

